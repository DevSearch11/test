import { Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { SelectCharacterComponent } from './select-character/select-character.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { KanbanComponent } from './kanban/kanban.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { ShopComponent } from './shop/shop.component';
import { NotificationComponent } from './notification/notification.component';
import { LeaderboardComponent } from './leaderboard/leaderboard.component';
import { QuestsComponent } from './quests/quests.component';

export const routes: Routes = [
    {path: "register", component: RegisterComponent},
    {path: "select-character", component: SelectCharacterComponent},
    {path: "dashboard", component: DashboardComponent},
    {path: "kanban", component: KanbanComponent},
    {path: "add-task", component: AddTaskComponent},
    {path: "shop", component: ShopComponent},
    {path: "leaderboard", component: LeaderboardComponent},
    {path: "quests", component: QuestsComponent},
    {path: "**", redirectTo: "register"},
];
