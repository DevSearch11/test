import { Component, OnDestroy, OnInit } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';

@Component({
  selector: 'app-quests',
  standalone: true,
  imports: [NavbarComponent],
  templateUrl: './quests.component.html',
  styleUrl: './quests.component.scss'
})
export class QuestsComponent implements OnInit, OnDestroy {
    reward: string = "reward_1"
    rewardCount: number = 1;
    xp: string = "xp_21"
    xpCount: number = 21;
    timeInterval: any;

    ngOnInit(): void {
        this.timeInterval = setInterval(() => {
            if(this.rewardCount < 10){
                this.reward = "reward_" + (++this.rewardCount);
            }
            else{
                this.reward = "reward_" + (this.rewardCount = 1);
            }
            if(this.xpCount < 30){
                this.xp = "xp_" + (++this.xpCount);
            }
            else{
                this.xp = "xp_" + (this.xpCount = 21);
            }
        }, 200)
    }

    ngOnDestroy(): void {
        if(this.timeInterval){
            clearInterval(this.timeInterval);
        }
    }
}
