import { Component } from '@angular/core';

@Component({
  selector: 'app-slogan',
  standalone: true,
  imports: [],
  templateUrl: './slogan.component.html',
  styleUrl: './slogan.component.scss'
})
export class SloganComponent {

}
